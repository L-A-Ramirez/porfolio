package com.TpFinal.porfolio.services;

import com.TpFinal.porfolio.entities.Persona;

import java.util.List;

public interface I_PersonaService {
    List<Persona> getAll();
    void save(Persona persona);
    void remove(Long id);
    Persona getById(Long id);
}
