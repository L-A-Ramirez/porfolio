package com.TpFinal.porfolio.services;

import com.TpFinal.porfolio.entities.Persona;
import com.TpFinal.porfolio.repositories.PersonaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonaService implements I_PersonaService {

    @Autowired
    private PersonaRepository repository;

    @Override
    public List<Persona> getAll() {
        //return (List<Persona>) repository.findAll();
        List<Persona> listPersonas = repository.findAll();
        return listPersonas;
    }

    @Override
    public void save(Persona persona) {
        repository.save(persona);
    }

    @Override
    public void remove(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Persona getById(Long id) {
        //return (Persona) repository.findById(id).get();
        Persona persona = repository.findById(id).orElse(null);
        return persona;
    }
}
