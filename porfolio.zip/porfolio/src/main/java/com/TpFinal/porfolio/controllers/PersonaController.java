package com.TpFinal.porfolio.controllers;

import com.TpFinal.porfolio.entities.Persona;
import com.TpFinal.porfolio.services.I_PersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class PersonaController {

    @Autowired
    I_PersonaService service;

    @GetMapping("/api/personas")
    public List<Persona> getAll() {
        return service.getAll();
    }

    @GetMapping("/api/personas/{id}")
    public Persona getById(@PathVariable String id) {
        return service.getById(Long.parseLong(id));
    }

    @DeleteMapping("/api/personas/{id}")
    public void remove(@PathVariable String id) {
        service.remove(Long.parseLong(id));
    }

    @PostMapping("/api/personas")
    public void save(@RequestBody Persona persona) {
        service.save(persona);
    }
}