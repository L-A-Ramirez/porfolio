package com.TpFinal.porfolio.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import org.springframework.data.annotation.Id;

@Entity
@Table(name = "personas")
@Getter @Setter
@ToString

public class Persona {

    @JdbcTypeCode(SqlTypes.INTEGER)
    @jakarta.persistence.Id
    @Column(name = "dni", nullable = false)
    private Integer dni;

    private String nombre;
    private String apellido;
    private String contacto;
    private String mail;
    private String acercademi;

}
